/* Official Telegram Post Widgets, activated by the visitor, not a copied chat. */
(function(){
  'use strict';
  const entries=Object.freeze({training:'zenitalanya/186',team:'zenitalanya/192'});
  const mount=document.querySelector('#telegram-embed');
  if(!mount)return;
  let active=null;
  const observer=new MutationObserver(()=>{
    const frame=mount.querySelector('iframe');
    if(frame)frame.title='Telegram · @zenitalanya · '+entries[active];
  });
  observer.observe(mount,{childList:true,subtree:true});
  function close(){mount.replaceChildren();mount.hidden=true;active=null;document.querySelectorAll('[data-telegram-entry]').forEach(b=>b.setAttribute('aria-expanded','false'));}
  document.querySelectorAll('[data-telegram-entry]').forEach(button=>button.addEventListener('click',()=>{
    const key=button.dataset.telegramEntry,post=entries[key];if(!post)return;
    if(active===key){close();return;}
    close();active=key;mount.hidden=false;button.setAttribute('aria-expanded','true');
    const script=document.createElement('script');script.async=true;
    script.src='https://telegram.org/js/telegram-widget.js?24';
    script.setAttribute('data-telegram-post',post);script.setAttribute('data-width','100%');script.setAttribute('data-userpic','false');
    script.setAttribute('data-color','007DA9');
    // The adjacent original links remain usable even if the provider is blocked.
    const host=document.createElement('div');host.append(script);mount.append(host);
  }));
})();
