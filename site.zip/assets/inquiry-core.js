(function(root){
  'use strict';
  const experiences=['beginner','some','regular'];
  const goals=['new','start','grow'];
  function effectiveGoal(goal,experience){
    if(!goals.includes(goal)||goal==='start'&&experience!=='beginner'||goal==='grow'&&experience!=='regular')return null;
    return goal;
  }
  function normalize(input){
    const raw=String(input.age??'').trim(),age=Number(raw);
    if(!/^\d{1,2}$/.test(raw)||!Number.isInteger(age)||age<1||age>18)return {error:'age'};
    if(!experiences.includes(input.experience))return {error:'experience'};
    return {age,experience:input.experience,goal:effectiveGoal(input.goal,input.experience),
      area:String(input.area??'').trim().slice(0,80),language:['ru','tr','en','other'].includes(input.language)?input.language:'ru',
      topic:['training','kit','trip'].includes(input.topic)?input.topic:'training'};
  }
  function buildMessage(input,t){
    const p=normalize(input);if(p.error)return p;
    const parts=[t.greeting,`${t.childLine}: ${p.age} ${t.years}.`,`${t.experienceLine}: ${t[p.experience]}.`];
    if(p.goal)parts.push(t['goalMessage_'+p.goal]);
    if(p.area)parts.push(`${t.areaLine}: ${p.area}.`);
    const languages={ru:'russian',tr:'turkish',en:'english',other:'other'};
    parts.push(`${t.languageLine}: ${t[languages[p.language]]}.`,'',t.questions[p.topic]);
    return {text:parts.join('\n')};
  }
  const api={normalize,buildMessage,effectiveGoal};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.ZenitInquiry=api;
})(typeof globalThis!=='undefined'?globalThis:this);
